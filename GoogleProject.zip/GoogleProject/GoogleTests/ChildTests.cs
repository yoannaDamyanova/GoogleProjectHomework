﻿using Google;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoogleTests
{
    [TestFixture]
    public class ChildTests
    {
        [Test]
        public void ToString_ReturnsCorrectString()
        {
            // Arrange
            Child child = new Child("Emily", "2010-08-25");

            // Act
            string result = child.ToString();

            // Assert
            Assert.AreEqual("Emily 2010-08-25", result);
        }

        [Test]
        public void NameProperty_CanBeSetAndRetrieved()
        {
            // Arrange
            Child child = new Child("Jacob", "2015-03-12");

            // Act
            string name = child.Name;

            // Assert
            Assert.AreEqual("Jacob", name);
        }

        [Test]
        public void BirthdateProperty_CanBeSetAndRetrieved()
        {
            // Arrange
            Child child = new Child("Sophia", "2018-11-30");

            // Act
            string birthdate = child.Birthdate;

            // Assert
            Assert.AreEqual("2018-11-30", birthdate);
        }
    }
}
