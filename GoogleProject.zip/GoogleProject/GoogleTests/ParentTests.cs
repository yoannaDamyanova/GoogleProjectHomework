﻿using Google;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoogleTests
{
    [TestFixture]
    public class ParentTests
    {
        [Test]
        public void ToString_ReturnsCorrectString()
        {
            // Arrange
            Parent parent = new Parent("John Doe", "1980-05-15");

            // Act
            string result = parent.ToString();

            // Assert
            Assert.AreEqual("John Doe 1980-05-15", result);
        }

        [Test]
        public void NameProperty_CanBeSetAndRetrieved()
        {
            // Arrange
            Parent parent = new Parent("Alice Smith", "1975-10-20");

            // Act
            string name = parent.Name;

            // Assert
            Assert.AreEqual("Alice Smith", name);
        }

        [Test]
        public void BirthdateProperty_CanBeSetAndRetrieved()
        {
            // Arrange
            Parent parent = new Parent("Michael Johnson", "1992-03-28");

            // Act
            string birthdate = parent.Birthdate;

            // Assert
            Assert.AreEqual("1992-03-28", birthdate);
        }
    }
    
}
