using Google;
using NUnit.Framework;

namespace GoogleTests
{
    [TestFixture]
    public class PokemonTests
    {
        [Test]
        public void ToString_ReturnsCorrectString()
        {
            // Arrange
            Pokemon pokemon = new Pokemon("Pikachu", "Electric");

            // Act
            string result = pokemon.ToString();

            // Assert
            Assert.AreEqual("Pikachu Electric", result);
        }

        [Test]
        public void NameProperty_CanBeSetAndRetrieved()
        {
            // Arrange
            Pokemon pokemon = new Pokemon("Charmander", "Fire");

            // Act
            string name = pokemon.Name;

            // Assert
            Assert.AreEqual("Charmander", name);
        }

        [Test]
        public void TypeProperty_CanBeSetAndRetrieved()
        {
            // Arrange
            Pokemon pokemon = new Pokemon("Squirtle", "Water");

            // Act
            string type = pokemon.Type;

            // Assert
            Assert.AreEqual("Water", type);
        }
    }
}