﻿using Google;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoogleTests
{
    [TestFixture]
    public class CarTests
    {
        [Test]
        public void ToString_ReturnsCorrectString()
        {
            // Arrange
            Car car = new Car("Tesla", 120);

            // Act
            string result = car.ToString();

            // Assert
            Assert.AreEqual("Tesla 120", result);
        }

        [Test]
        public void ModelProperty_CanBeSetAndRetrieved()
        {
            // Arrange
            Car car = new Car("Toyota", 90);

            // Act
            string model = car.Model;

            // Assert
            Assert.AreEqual("Toyota", model);
        }

        [Test]
        public void SpeedProperty_CanBeSetAndRetrieved()
        {
            // Arrange
            Car car = new Car("Honda", 100);

            // Act
            int speed = car.Speed;

            // Assert
            Assert.AreEqual(100, speed);
        }
    }
}
