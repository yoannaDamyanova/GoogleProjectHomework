﻿using Google;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoogleTests
{
    public class PersonTests
    {
        [Test]
        public void Constructor_WorksCorrectly()
        {
            //Arrange
            Person person = new("John");

            //Assert
            Assert.AreEqual(person.Name, "John");
            Assert.AreEqual(person.Pokemons.Count, 0);
            Assert.AreEqual(person.Children.Count, 0);
            Assert.AreEqual(person.Parents.Count, 0);
        }
        [Test]
        public void ToString_ReturnsCorrectString_WithNoDetails()
        {
            // Arrange
            Person person = new Person("John");

            // Act
            string result = person.ToString();

            // Assert
            string expected = "John\r\nComapany: \r\nCar: \r\nPokemons: \r\nParents: \r\nChildren:";
            Assert.AreEqual(expected, result);
        }

        [Test]
        public void ToString_ReturnsCorrectString_WithDetails()
        {
            // Arrange
            Company company = new Company("ABC Corp", "Engineering", 50000.0);
            Car car = new Car("Tesla", 120);
            List<Pokemon> pokemons = new List<Pokemon> { new Pokemon("Pikachu", "Electric") };
            List<Parent> parents = new List<Parent> { new Parent("Alice", "1970-01-01") };
            List<Child> children = new List<Child> { new Child("Bob", "2000-01-01") };

            Person person = new Person("Alice");
            person.CompanyDetails = company;
            person.CarDetails = car;
            person.Pokemons = pokemons;
            person.Parents = parents;
            person.Children = children;

            // Act
            string result = person.ToString();

            // Assert
            string expected = "Alice\r\nComapany: ABC Corp Engineering 50000\r\nCar: Tesla 120\r\nPokemons: Pikachu Electric\r\nParents: Alice 1970-01-01\r\nChildren: Bob 2000-01-01";
            Assert.AreEqual(expected, result);
        }
    }
}
