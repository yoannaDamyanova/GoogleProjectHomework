﻿using Google;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoogleTests
{
    [TestFixture]
    public class CompanyTests
    {
        [Test]
        public void ToString_ReturnsCorrectString()
        {
            // Arrange
            Company company = new Company("ABC Corp", "Engineering", 50000.0);

            // Act
            string result = company.ToString();

            // Assert
            Assert.AreEqual("ABC Corp Engineering 50000", result);
        }

        [Test]
        public void NameProperty_CanBeSetAndRetrieved()
        {
            // Arrange
            Company company = new Company("XYZ Inc", "Marketing", 60000.0);

            // Act
            string name = company.Name;

            // Assert
            Assert.AreEqual("XYZ Inc", name);
        }

        [Test]
        public void DepartmentProperty_CanBeSetAndRetrieved()
        {
            // Arrange
            Company company = new Company("LMN Ltd", "Sales", 55000.0);

            // Act
            string department = company.Department;

            // Assert
            Assert.AreEqual("Sales", department);
        }

        [Test]
        public void SalaryProperty_CanBeSetAndRetrieved()
        {
            // Arrange
            Company company = new Company("PQR Co", "HR", 70000.0);

            // Act
            double salary = company.Salary;

            // Assert
            Assert.AreEqual(70000.0, salary);
        }
    }
}
