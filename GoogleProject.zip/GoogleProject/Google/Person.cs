﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Google
{
    public class Person
    {
        public Person(string name)
        {
            Name = name;
            Children = new List<Child>();
            Parents = new List<Parent>();
            Pokemons = new List<Pokemon>();
        }

        public string Name { get; set; }
        public Company CompanyDetails { get; set; }
        public Car CarDetails { get; set; }
        public List<Child> Children { get; set; }
        public List<Parent> Parents { get; set; }
        public List<Pokemon> Pokemons { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(Name);
            string company = CompanyDetails != null ? CompanyDetails.ToString() : string.Empty;
            sb.AppendLine($"Comapany: {company}");
            string car = CarDetails != null ? CarDetails.ToString() : string.Empty;
            sb.AppendLine($"Car: {car}");
            string pokemons = Pokemons.Any() ? string.Join(", ", Pokemons) : string.Empty;
            sb.AppendLine($"Pokemons: {pokemons}");
            string parents  = Parents.Any() ? string.Join(", ", Parents) : string.Empty;
            sb.AppendLine($"Parents: {parents}");
            string children = Parents.Any() ? string.Join(", ", Children) : string.Empty;
            sb.AppendLine($"Children: {children}");
            return sb.ToString().TrimEnd();
        }
    }
}
