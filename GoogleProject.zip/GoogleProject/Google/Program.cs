﻿using Google;

Dictionary<string, Person> people = new Dictionary<string, Person>();



string input = Console.ReadLine();
while (input != "End")
{
    if (input == "End")
    {
        break;
    }

    string[] inputArgs = input.Split(' ', StringSplitOptions.RemoveEmptyEntries);
    string personName = inputArgs[0];
    string commandType = inputArgs[1];
    string[] commandArgs = inputArgs.Skip(2).ToArray();
    if (!people.ContainsKey(personName))
    {
        people.Add(personName, new Person(personName));
    }
    switch (commandType)
    {
        case "company":
            {
                string companyName = commandArgs[0];
                string department = commandArgs[1];
                double salary = double.Parse(commandArgs[2]);
                people[personName].CompanyDetails = new Company(companyName, department, salary);
            }
            break;
        case "car":
            {
                string model = commandArgs[0];
                int speed = int.Parse(commandArgs[1]);
                people[personName].CarDetails = new Car(model, speed);
            }
            break;
        case "children":
            {
                string name = commandArgs[0];
                string birthdate = commandArgs[1];
                people[personName].Children.Add(new Child(name, birthdate));
            }
            break;
        case "parents":
            {
                string name = commandArgs[0];
                string birthdate = commandArgs[1];
                people[personName].Parents.Add(new Parent(name, birthdate));
            }
            break;
        case "pokemon":
            {
                string name = commandArgs[0];
                string type = commandArgs[1];
                people[personName].Pokemons.Add(new Pokemon(name, type));
            }
            break;
        default:
            break;
    }
    input = Console.ReadLine();
}
string report = Console.ReadLine();
if (people.ContainsKey(report))
{
    Console.WriteLine(people[report].ToString());
}