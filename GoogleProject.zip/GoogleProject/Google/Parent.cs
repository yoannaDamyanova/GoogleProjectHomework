﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Google
{
    public class Parent
    {
        public Parent(string name, string birthdate)
        {
            Name = name;
            Birthdate = birthdate;
        }

        public string Name { get; set; }
        public string Birthdate { get; set; }
        public override string ToString()
        {
            return $"{Name} {Birthdate}";
        }
    }
}
